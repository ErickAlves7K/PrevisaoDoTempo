package aula16;

import javax.swing.*;

public class Images {

	JLabel windy = new JLabel(new ImageIcon(getClass().getResource("iconfinder_Windy_3741354.png")));
}
